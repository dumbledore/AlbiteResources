package test;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import gnu.zip.CRC32;
import gnu.zip.CheckedInputStream;
import gnu.zip.ZipEntry;
import gnu.zip.ZipFile;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.microedition.midlet.*;
import org.albite.io.RandomReadingFile;

/**
 * @author Svetlin Ankov <galileostudios@gmail.com>
 */
public class Test extends MIDlet {
    boolean initialized = false;
    public void startApp() {
        if (!initialized) {
            initialize();
            initialized = true;
        }
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
    }

    private void initialize() {
        try {
            ZipFile zip = new ZipFile(new RandomReadingFile("file:///root1/test.zip"));
            ZipEntry entry = zip.getEntry("chapter06.xhtml");

            InputStream in = zip.getInputStream(entry);
            CheckedInputStream check = new CheckedInputStream(in, new CRC32());

            InputStreamReader r = new InputStreamReader(in, "UTF-8");

            StringBuffer sb = new StringBuffer();
            char[] buffer = new char[400000];

            int read;

            while ((read = r.read(buffer)) > 0) {
                sb.append(buffer, 0, read);
            }

            in.close();

            System.out.println(new String(sb));

            System.out.println("len: " + sb.length());
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
}
