/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.albite.dictionary.builder;

/**
 *
 * @author albus
 */
public class DictBuilderException extends Exception {
    public DictBuilderException() {
        super();
    }

    public DictBuilderException(String s) {
        super(s);
    }
}
