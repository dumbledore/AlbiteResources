
The full license for this font can be found at >
http://new.myfonts.com/fonts/exljbris/museo-slab/buy.html